export default {
  i18n: {
    defaultLocale: 'ar', // Ajusta el idioma predeterminado
    locales: ['ar', 'pe', 'co'], // Lista de idiomas soportados
  },
  ns: ['common', 'home'], // Añade los namespaces que estás usando
  react: { useSuspense: false }, // Para evitar errores con SSR en Next.js
};